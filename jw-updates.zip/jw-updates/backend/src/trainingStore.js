/**
 * Training Store
 *
 * Key improvements over previous version:
 *
 * 1. IN-MEMORY CACHE (30s TTL)
 *    For 1000+ image batch uploads, the lessons.json was read from disk for every
 *    single image. Now it's read once and cached. 1000 uploads = 1 disk read.
 *
 * 2. SMART LESSON SELECTION via getLessonsForPrompt(manualTags)
 *    Old behaviour: always return 6 most-recent lessons regardless of relevance.
 *    New behaviour:
 *      a. Score every lesson by relevance to the image's manual tags
 *         (+10 per matching tag field — e.g. category:"Ring" matching a Ring lesson)
 *      b. Greedily select lessons ensuring coverage across all teaching dimensions
 *         (settingStyle, prong, shank, metalColor, stoneShapes, gemstone, etc.)
 *         At most 2 lessons per specific dimension value to avoid redundancy
 *      c. Cap at MAX_LESSONS_IN_PROMPT (raised from 6 → 20)
 *
 *    This means:
 *      - Uploading a Rose Gold Ring → Ring lessons and Rose Gold lessons get priority
 *      - All 20 slots filled with diverse dimensions, not 20 identical metal lessons
 *      - An image needing settingStyle + prong + shank knowledge gets all three covered
 *      - If only 3 lessons exist → all 3 are used (no artificial cap when under MAX)
 */

import fs   from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { fileURLToPath }  from 'url';

const __dirname    = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR     = path.join(__dirname, '..', 'training-data');
const LESSONS_FILE = path.join(DATA_DIR, 'lessons.json');

// Maximum lessons included in a single GPT-4o Mini tagging call.
// Each lesson ≈ 85 tokens (image, detail:low) + ~150 tokens (name + tags JSON).
// 20 lessons ≈ 4,700 extra tokens per call at ~$0.00021 extra cost — negligible.
// GPT-4o Mini's 128K context handles this comfortably.
export const MAX_LESSONS_IN_PROMPT = 20;

// Teaching dimensions — the tag fields lessons can teach.
// Ordered by importance: specific design details first, then general attributes.
const TEACHING_DIMENSIONS = [
  'settingStyle',   // most important — highly specific visual pattern
  'prong',          // second most important for rings
  'shank',
  'metalColor',
  'stoneShapes',
  'gemstone',
  'diamondColor',
  'category',
  'subCategory',
  'hasRhodium',
  'cut',
];

// ─── In-memory cache ────────────────────────────────────────────────────────
// Avoids re-reading the JSON file for every image in a large batch upload.
let _cache     = null;
let _cacheTime = 0;
const CACHE_TTL = 30_000; // 30 seconds — lessons rarely change mid-upload

function readAll() {
  const now = Date.now();
  if (_cache && (now - _cacheTime) < CACHE_TTL) return _cache;

  ensureDir();
  if (!fs.existsSync(LESSONS_FILE)) {
    _cache = [];
    _cacheTime = now;
    return _cache;
  }
  try {
    _cache     = JSON.parse(fs.readFileSync(LESSONS_FILE, 'utf8'));
    _cacheTime = now;
    return _cache;
  } catch {
    _cache = [];
    _cacheTime = now;
    return _cache;
  }
}

function writeAll(lessons) {
  ensureDir();
  fs.writeFileSync(LESSONS_FILE, JSON.stringify(lessons, null, 2));
  // Invalidate cache immediately so next read sees the updated data
  _cache     = lessons;
  _cacheTime = Date.now();
}

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ─── Public CRUD API ────────────────────────────────────────────────────────

export function getAllLessons(withBase64 = false) {
  const lessons = readAll();
  if (withBase64) return lessons;
  return lessons.map(({ imageBase64, ...rest }) => rest);
}

export function getLessonById(id) {
  const lesson = readAll().find((l) => l.id === id);
  if (!lesson) throw new Error(`Lesson not found: ${id}`);
  return lesson;
}

export function createLesson({ name, description = '', imageUrl, imageBase64, mediaType, tags = {} }) {
  if (!name?.trim())  throw new Error('name is required');
  if (!imageBase64)   throw new Error('imageBase64 is required');
  if (!imageUrl)      throw new Error('imageUrl is required');

  const lessons = readAll();
  const lesson  = {
    id:          uuidv4(),
    name:        name.trim(),
    description: description.trim(),
    imageUrl,
    imageBase64,
    mediaType:   mediaType || 'image/webp',
    tags,
    createdAt:   new Date().toISOString(),
    updatedAt:   new Date().toISOString(),
  };
  lessons.push(lesson);
  writeAll(lessons);

  const { imageBase64: _, ...pub } = lesson;
  return pub;
}

export function updateLesson(id, patch) {
  const lessons = readAll();
  const idx     = lessons.findIndex((l) => l.id === id);
  if (idx === -1) throw new Error(`Lesson not found: ${id}`);

  lessons[idx] = { ...lessons[idx], ...patch, id, updatedAt: new Date().toISOString() };
  writeAll(lessons);

  const { imageBase64: _, ...pub } = lessons[idx];
  return pub;
}

export function deleteLesson(id) {
  const lessons  = readAll();
  const filtered = lessons.filter((l) => l.id !== id);
  if (filtered.length === lessons.length) throw new Error(`Lesson not found: ${id}`);
  writeAll(filtered);
}

// ─── Smart Lesson Selection ─────────────────────────────────────────────────

/**
 * Select the most relevant and diverse lessons for a GPT-4o Mini tagging call.
 *
 * @param {object} manualTags — tags the user already provided for this image
 *                              (used to prioritise lessons that match)
 * @returns {object[]} up to MAX_LESSONS_IN_PROMPT lessons, each with imageBase64
 */
export function getLessonsForPrompt(manualTags = {}) {
  const all = readAll(); // uses cache — O(1) for batch uploads
  if (all.length === 0) return [];
  if (all.length <= MAX_LESSONS_IN_PROMPT) return all; // use every lesson when we have few

  // ── Step 1: Score every lesson ───────────────────────────────────────────
  const scored = all.map((lesson) => {
    let score    = 0;
    const ltags  = lesson.tags || {};

    // Relevance bonus: does this lesson's tags match the manual tags?
    // e.g. category:"Ring" in manual tags → Ring lessons score +10
    for (const [key, val] of Object.entries(manualTags)) {
      if (!val) continue;
      const lv = ltags[key];
      if (lv === null || lv === undefined) continue;

      const match = Array.isArray(lv)
        ? (Array.isArray(val) ? val.some((v) => lv.includes(v)) : lv.includes(val))
        : (Array.isArray(val) ? val.includes(lv) : lv === val);

      if (match) score += 10;
    }

    // Coverage bonus: how many distinct teaching dimensions does this lesson cover?
    // Lessons that teach rare/specific patterns are more valuable
    for (const dim of TEACHING_DIMENSIONS) {
      const v = ltags[dim];
      const hasValue =
        v !== null && v !== undefined && v !== false &&
        !(Array.isArray(v) && v.length === 0);
      if (hasValue) score += 1;
    }

    return { lesson, score };
  });

  // Sort highest score first
  scored.sort((a, b) => b.score - a.score);

  // ── Step 2: Greedy diversity selection ──────────────────────────────────
  // Pick lessons greedily, ensuring we cover as many unique dimension values
  // as possible. Allow at most 2 lessons per specific (dimension, value) pair
  // to avoid flooding the prompt with, e.g., 15 "Rose Gold" lessons.

  const selected           = [];
  const dimensionCount     = new Map(); // "metalColor:Rose Gold" → count

  const canAdd = (lesson) => {
    const ltags  = lesson.tags || {};
    for (const dim of TEACHING_DIMENSIONS) {
      const v = ltags[dim];
      const hasValue =
        v !== null && v !== undefined && v !== false &&
        !(Array.isArray(v) && v.length === 0);
      if (hasValue) {
        const dimKey = `${dim}:${Array.isArray(v) ? v[0] : v}`;
        const count  = dimensionCount.get(dimKey) || 0;
        if (count < 2) return true; // this lesson adds new coverage
      }
    }
    return false;
  };

  const recordDimensions = (lesson) => {
    const ltags = lesson.tags || {};
    for (const dim of TEACHING_DIMENSIONS) {
      const v = ltags[dim];
      const hasValue =
        v !== null && v !== undefined && v !== false &&
        !(Array.isArray(v) && v.length === 0);
      if (hasValue) {
        const dimKey = `${dim}:${Array.isArray(v) ? v[0] : v}`;
        dimensionCount.set(dimKey, (dimensionCount.get(dimKey) || 0) + 1);
      }
    }
  };

  // First pass: add only lessons that provide new coverage
  for (const { lesson } of scored) {
    if (selected.length >= MAX_LESSONS_IN_PROMPT) break;
    if (canAdd(lesson)) {
      selected.push(lesson);
      recordDimensions(lesson);
    }
  }

  // Second pass: if we still have slots, fill with highest-scored remaining lessons
  // (ensures we always send MAX_LESSONS_IN_PROMPT when enough lessons exist)
  if (selected.length < MAX_LESSONS_IN_PROMPT) {
    const selectedIds = new Set(selected.map((l) => l.id));
    for (const { lesson } of scored) {
      if (selected.length >= MAX_LESSONS_IN_PROMPT) break;
      if (!selectedIds.has(lesson.id)) {
        selected.push(lesson);
        selectedIds.add(lesson.id);
      }
    }
  }

  console.log(
    `  [TrainingStore] Selected ${selected.length}/${all.length} lessons` +
    (Object.keys(manualTags).length
      ? ` (matched to: ${JSON.stringify(manualTags)})`
      : ' (no manual tags — diversity-based selection)')
  );

  return selected;
}

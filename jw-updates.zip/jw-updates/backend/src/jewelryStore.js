/**
 * Jewelry Store
 * Change from previous version: passes manualTags to getLessonsForPrompt()
 * so the lesson selection algorithm can prioritise matching lessons.
 */

import { v4 as uuidv4 }            from 'uuid';
import { getPineconeIndex }         from './pineconeClient.js';
import { embedText }                from './embedder.js';
import { autoTagImage, buildSearchableText } from './visionTagger.js';
import { getLessonsForPrompt }      from './trainingStore.js';

export async function addJewelryImage({
  imageUrl,
  fileName,
  fileBuffer,
  sku,
  tags: manualTags = {},
  autoTag          = true,
  editableData     = null,
  userPrompt       = null,
}) {
  console.log(`\n━━━ Adding: ${fileName} ━━━`);

  let autoTags = {};

  if (autoTag) {
    console.log('  → Auto-tagging with GPT-4o Mini...');

    const lessons = (editableData === null && userPrompt === null)
      ? getLessonsForPrompt(manualTags)  // ← pass manualTags for smart selection
      : [];

    if (lessons.length > 0) {
      console.log(`  → Using ${lessons.length} lesson${lessons.length !== 1 ? 's' : ''} for few-shot tagging`);
    }

    autoTags = await autoTagImage(fileBuffer, fileName, editableData, userPrompt, lessons);
    console.log('  → Tags:', JSON.stringify(autoTags, null, 4));
  }

  const finalTags      = mergeDeep(autoTags, manualTags);
  const searchableText = buildSearchableText(finalTags);
  console.log('  → Searchable text:', searchableText);

  console.log('  → Generating embedding...');
  const embedding = await embedText(searchableText);

  const id = sku || uuidv4();
  const metadata = {
    id,
    imageUrl,
    fileName,
    sku:           sku || id,
    searchableText,
    addedAt:       new Date().toISOString(),
    ...flattenForPinecone(finalTags),
  };

  const index = await getPineconeIndex();
  await index.upsert([{ id, values: embedding, metadata }]);

  console.log(`  ✓ Stored in Pinecone → ID: ${id}`);
  return { id, tags: finalTags, searchableText };
}

export async function addBatch(items) {
  const results = [];
  for (const item of items) {
    try {
      results.push({ success: true, ...(await addJewelryImage(item)) });
    } catch (err) {
      console.error(`  ✗ Failed: ${item.fileName}: ${err.message}`);
      results.push({ success: false, fileName: item.fileName, error: err.message });
    }
  }
  return results;
}

export async function updateJewelryTags(id, updatedTags) {
  const index    = await getPineconeIndex();
  const fetched  = await index.fetch([id]);
  const existing = fetched.vectors?.[id] ?? fetched.records?.[id];
  if (!existing) throw new Error(`No jewelry found with ID: ${id}`);

  const newMeta = { ...(existing.metadata || {}), ...flattenForPinecone(updatedTags) };
  newMeta.searchableText = buildSearchableText(newMeta);

  const newEmbedding = await embedText(newMeta.searchableText);
  await index.upsert([{ id, values: newEmbedding, metadata: newMeta }]);
  return { id, metadata: newMeta };
}

function flattenForPinecone(tags) {
  const flat = {};
  for (const [key, val] of Object.entries(tags)) {
    if (val === null || val === undefined) continue;
    if (Array.isArray(val)) flat[key] = val.filter(Boolean).map(String);
    else if (typeof val !== 'object') flat[key] = val;
  }
  return flat;
}

function mergeDeep(base, override) {
  const result = { ...base };
  for (const [key, val] of Object.entries(override)) {
    if (val !== null && val !== undefined && val !== '') result[key] = val;
  }
  return result;
}

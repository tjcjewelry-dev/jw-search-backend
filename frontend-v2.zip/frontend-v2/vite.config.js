import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: "/jw-search/",
  server: {
    port: 5173,
    proxy: {
      // All /api and /uploads requests go to Express
      '/api':     { target: 'https://jw-search-backend.onrender.com', changeOrigin: true },
      '/uploads': { target: 'https://jw-search-backend.onrender.com', changeOrigin: true },
    },
  },
});

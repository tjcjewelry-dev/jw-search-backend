/**
 * useInfiniteScroll
 *
 * Attach the returned `sentinelRef` to a div at the bottom of your list.
 * When that div scrolls into view (+ 200px of margin), `onLoadMore` is called.
 *
 * Usage:
 *   const sentinelRef = useInfiniteScroll(loadMore, hasMore);
 *   ...
 *   <div ref={sentinelRef} />
 */
import { useEffect, useRef, useCallback } from 'react';

export function useInfiniteScroll(onLoadMore, hasMore) {
  const sentinelRef  = useRef(null);
  const observerRef  = useRef(null);
  const stableLoad   = useCallback(onLoadMore, []);

  useEffect(() => {
    // Disconnect previous observer before creating a new one
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore) {
          stableLoad();
        }
      },
      { rootMargin: '200px' },
    );

    if (sentinelRef.current) observerRef.current.observe(sentinelRef.current);
    return () => observerRef.current?.disconnect();
  }, [hasMore, stableLoad]);

  return sentinelRef;
}

import { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import useJewelryStore from '../store/useJewelryStore.js';
import ResultCard from '../components/ResultCard.jsx';
import { useInfiniteScroll } from '../hooks/useInfiniteScroll.js';

const FILTER_DEFS = [
  { key: 'category',    label: 'Category',    opts: ['Ring','Earring','Pendant','Bracelet','Bangle','Necklace','Brooch','Anklet','Nose Pin'] },
  { key: 'metalColor',  label: 'Metal',        opts: ['Yellow Gold','White Gold','Rose Gold','Two Tone','Tri Color','Platinum','Sterling Silver'] },
  { key: 'stoneShapes', label: 'Stone Shape',  isArrayField: true,
    opts: ['ROUND','PEAR','OVAL','MARQUISE','PRINCESS','CUSHION','EMERALD','RADIANT','HEART',
           'BAGUETTE','ASCHER','HEXAGON','KITE','Trillion','HALF MOON',
           'ELONGATED PEAR','ELONGATED MARQUISE','ELONGATED OVAL'] },
  { key: 'gemstone',    label: 'Gemstone',     opts: ['Diamond','Ruby','Sapphire','Emerald','Topaz','Amethyst','Citrine','Garnet','Morganite','Opal','Pearl'] },
];

const Spinner = ({ size = 4, className = '' }) => (
  <svg className={`animate-spin w-${size} h-${size} shrink-0 ${className}`} viewBox="0 0 24 24" fill="none">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
  </svg>
);

export default function SearchPage() {
  const {
    searchMode, searchQuery, searchFilters, searchLabel,
    isSearching, searchError,
    searchImageFile, searchImagePreview,
    setSearchMode, setSearchQuery, setSearchFilter, clearFilters,
    setSearchImage, search,
    allResults, displayedCount, PAGE_SIZE, loadMore, hasMore, searchResults,
    selectedIds, selectMode, toggleSelectMode, toggleSelectId, selectAll, clearSelection,
    isBulkEditing, bulkEditProgress, bulkEditTags,
    isExtracting, extractImages,
  } = useJewelryStore((s) => ({
    searchMode:         s.searchMode,
    searchQuery:        s.searchQuery,
    searchFilters:      s.searchFilters,
    searchLabel:        s.searchLabel,
    isSearching:        s.isSearching,
    searchError:        s.searchError,
    searchImageFile:    s.searchImageFile,
    searchImagePreview: s.searchImagePreview,
    setSearchMode:      s.setSearchMode,
    setSearchQuery:     s.setSearchQuery,
    setSearchFilter:    s.setSearchFilter,
    clearFilters:       s.clearFilters,
    setSearchImage:     s.setSearchImage,
    search:             s.search,
    allResults:         s.allResults,
    displayedCount:     s.displayedCount,
    PAGE_SIZE:          s.PAGE_SIZE,
    loadMore:           s.loadMore,
    hasMore:            s.hasMore,
    searchResults:      s.searchResults,
    selectedIds:        s.selectedIds,
    selectMode:         s.selectMode,
    toggleSelectMode:   s.toggleSelectMode,
    toggleSelectId:     s.toggleSelectId,
    selectAll:          s.selectAll,
    clearSelection:     s.clearSelection,
    isBulkEditing:      s.isBulkEditing,
    bulkEditProgress:   s.bulkEditProgress,
    bulkEditTags:       s.bulkEditTags,
    isExtracting:       s.isExtracting,
    extractImages:      s.extractImages,
  }));

  const [bulkPrompt, setBulkPrompt] = useState('');
  const [bulkError,  setBulkError]  = useState(null);

  const visibleResults = searchResults();
  const more           = hasMore();
  const totalFetched   = allResults.length;
  const activeFilters  = Object.keys(searchFilters).length;
  const selectedCount  = selectedIds.size;
  const visibleCount   = Math.min(displayedCount, totalFetched);

  // ── Infinite scroll ──────────────────────────────────────────────────────
  // sentinelRef is attached to a div at the bottom of the grid.
  // IntersectionObserver fires loadMore() when it enters the viewport.
  // No extra API calls — just reveals more items from the already-fetched pool.
  const sentinelRef = useInfiniteScroll(loadMore, more);

  const handleKey = (e) => { if (e.key === 'Enter' && searchQuery.trim()) search(); };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { 'image/*': ['.jpg','.jpeg','.png','.webp'] },
    multiple: false,
    maxSize: 20 * 1024 * 1024,
    onDropAccepted: ([file]) => { setSearchImage(file); setSearchMode('image'); },
  });

  const handleBulkEdit = async () => {
    if (!bulkPrompt.trim()) return;
    setBulkError(null);
    try {
      await bulkEditTags(bulkPrompt.trim());
      setBulkPrompt('');
    } catch (err) {
      setBulkError(err.message);
    }
  };

  const showEmptyAfterSearch =
    !isSearching && !searchError && totalFetched === 0 &&
    (searchQuery.trim() || searchImageFile || searchLabel);

  const showInitialState =
    !isSearching && !searchError && totalFetched === 0 && !searchLabel;

  return (
    <div className="max-w-6xl mx-auto space-y-5">

      {/* ── Header ── */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Search Catalog</h1>
        <p className="text-gray-500 text-sm mt-1">
          Find jewelry by description or upload a reference image.
        </p>
      </div>

      {/* ── Mode toggle ── */}
      <div className="flex gap-2">
        {[{ mode: 'text', label: '🔤 Text Search' }, { mode: 'image', label: '🖼️ Image Search' }].map(({ mode, label }) => (
          <button
            key={mode}
            onClick={() => setSearchMode(mode)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              searchMode === mode
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-white text-gray-600 border border-gray-200 hover:border-amber-300'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* ── Text search ── */}
      {searchMode === 'text' && (
        <div className="card p-4 space-y-3">
          <div className="flex gap-2">
            <input
              className="input flex-1"
              placeholder="e.g. marquise yellow gold ring, rose gold earrings…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKey}
              autoFocus
            />
            <button
              onClick={search}
              disabled={isSearching || !searchQuery.trim()}
              className="btn-gold px-6 flex items-center gap-2"
            >
              {isSearching && <Spinner />}
              {isSearching ? 'Searching…' : 'Search'}
            </button>
          </div>
          <p className="text-xs text-gray-400 bg-gray-50 rounded-lg px-3 py-1.5">
            💡 Metal colors, categories, and stone shapes are applied as exact filters.
          </p>
          <div className="flex flex-wrap gap-2 items-center">
            <span className="text-xs text-gray-400 font-medium uppercase tracking-wide">Filter:</span>
            {FILTER_DEFS.map(({ key, label, opts, isArrayField }) => (
              <select
                key={key}
                className="select py-1 text-xs w-auto"
                value={isArrayField
                  ? (Array.isArray(searchFilters[key]) ? searchFilters[key][0] : '')
                  : (searchFilters[key] || '')}
                onChange={(e) => {
                  const val = e.target.value;
                  setSearchFilter(key, isArrayField && val ? [val] : val);
                }}
              >
                <option value="">{label}</option>
                {opts.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            ))}
            {activeFilters > 0 && (
              <button onClick={clearFilters} className="text-xs text-red-400 hover:text-red-600">
                ✕ Clear ({activeFilters})
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── Image search ── */}
      {searchMode === 'image' && (
        <div className="card p-4 space-y-4">
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
              isDragActive ? 'border-amber-400 bg-amber-50' : 'border-gray-200 hover:border-amber-300 hover:bg-amber-50/40'
            }`}
          >
            <input {...getInputProps()} />
            {searchImagePreview ? (
              <div className="flex flex-col items-center gap-3">
                <img src={searchImagePreview} alt="Query" className="w-32 h-32 object-cover rounded-lg shadow-md" />
                <p className="text-sm text-gray-500">{searchImageFile?.name}</p>
                <p className="text-xs text-amber-600">Drop a different image to replace</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <div className="text-3xl">🖼️</div>
                <p className="font-medium text-gray-600">Drop a reference photo</p>
                <p className="text-sm text-gray-400">AI will tag it and find similar pieces</p>
              </div>
            )}
          </div>
          <button
            onClick={search}
            disabled={isSearching || !searchImageFile}
            className="btn-gold w-full flex items-center justify-center gap-2"
          >
            {isSearching && <Spinner />}
            {isSearching ? 'Analyzing image…' : 'Find Similar Jewelry'}
          </button>
        </div>
      )}

      {/* ── Error ── */}
      {searchError && (
        <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3">
          ⚠️ {searchError}
        </div>
      )}

      {/* ── Results toolbar ── */}
      {totalFetched > 0 && (
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <p className="text-gray-700 font-semibold">
              {visibleCount} of {totalFetched} results
            </p>
            {searchLabel && (
              <span className="text-xs text-gray-400 bg-gray-100 rounded-full px-3 py-1">
                {searchLabel}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex gap-3 text-xs text-gray-400 mr-1">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-400 inline-block"/>≥80%</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400 inline-block"/>60–80%</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-300 inline-block"/>&lt;60%</span>
            </div>
            <button
              onClick={toggleSelectMode}
              className={`text-xs font-medium px-3 py-1.5 rounded-lg border transition-all ${
                selectMode
                  ? 'bg-amber-500 text-white border-amber-500'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-amber-300'
              }`}
            >
              {selectMode ? '✕ Cancel' : '☑ Select'}
            </button>
          </div>
        </div>
      )}

      {/* ── Bulk action panel ── */}
      {selectMode && totalFetched > 0 && (
        <div className="card p-4 space-y-4 border-amber-200 bg-amber-50/40">

          {/* Selection controls row */}
          <div className="flex items-center gap-3 flex-wrap">
            <p className="text-sm font-semibold text-amber-800">
              {selectedCount === 0 ? 'Select items to act on' : `${selectedCount} selected`}
            </p>
            <div className="flex gap-3 ml-auto text-xs">
              <button onClick={selectAll} className="text-amber-700 hover:text-amber-900 underline">
                All {visibleCount} visible
              </button>
              {selectedCount > 0 && (
                <button onClick={clearSelection} className="text-gray-500 hover:text-gray-700 underline">
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* ── Two action areas side by side ── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

            {/* Extract images */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
              <div>
                <p className="text-sm font-semibold text-gray-800">📥 Extract Images</p>
                <p className="text-xs text-gray-500 mt-0.5">
                  Download selected images.
                  Single = direct download · Multiple = ZIP file.
                </p>
              </div>
              <button
                onClick={extractImages}
                disabled={selectedCount === 0 || isExtracting}
                className="w-full flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600
                           active:bg-blue-700 text-white font-semibold rounded-lg px-4 py-2 text-sm
                           transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isExtracting ? (
                  <><Spinner /> Downloading…</>
                ) : (
                  <>⬇ Extract {selectedCount > 0 ? selectedCount : ''} Image{selectedCount !== 1 ? 's' : ''}</>
                )}
              </button>
              {selectedCount > 1 && !isExtracting && (
                <p className="text-xs text-gray-400 text-center">
                  Will be packaged as a .zip file
                </p>
              )}
            </div>

            {/* Re-tag */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
              <div>
                <p className="text-sm font-semibold text-gray-800">✏️ Re-Tag Items</p>
                <p className="text-xs text-gray-500 mt-0.5">
                  Apply one correction prompt to all selected items.
                </p>
              </div>
              <textarea
                className="w-full min-h-[64px] border border-gray-200 rounded-lg p-2.5
                           outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-100
                           text-sm resize-none bg-gray-50"
                placeholder="e.g. metal color is Rose Gold, hasRhodium is true…"
                value={bulkPrompt}
                onChange={(e) => setBulkPrompt(e.target.value)}
                disabled={isBulkEditing}
              />
              {bulkError && <p className="text-xs text-red-500">{bulkError}</p>}
              {isBulkEditing && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-gray-500">
                    <span className="flex items-center gap-1"><Spinner size={3} /> Processing {bulkEditProgress.current}/{bulkEditProgress.total}</span>
                    <span>{Math.round((bulkEditProgress.current / bulkEditProgress.total) * 100)}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500 rounded-full transition-all duration-300"
                      style={{ width: `${(bulkEditProgress.current / bulkEditProgress.total) * 100}%` }} />
                  </div>
                </div>
              )}
              <button
                onClick={handleBulkEdit}
                disabled={selectedCount === 0 || !bulkPrompt.trim() || isBulkEditing}
                className="w-full btn-gold text-sm flex items-center justify-center gap-2"
              >
                {isBulkEditing && <Spinner />}
                {isBulkEditing
                  ? `Re-tagging ${bulkEditProgress.current}/${bulkEditProgress.total}…`
                  : `Re-Tag ${selectedCount > 0 ? selectedCount : ''} Item${selectedCount !== 1 ? 's' : ''}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Results grid ── */}
      {visibleResults.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {visibleResults.map((result) => (
            <ResultCard key={result.id} result={result} />
          ))}
        </div>
      )}

      {/* ── Infinite scroll sentinel + loading indicator ── */}
      {totalFetched > 0 && (
        <div ref={sentinelRef} className="flex items-center justify-center py-6">
          {more ? (
            <div className="flex items-center gap-2 text-gray-400 text-sm">
              <Spinner />
              <span>Loading more…</span>
            </div>
          ) : visibleResults.length > 0 ? (
            <p className="text-xs text-gray-400">
              All {totalFetched} results shown
            </p>
          ) : null}
        </div>
      )}

      {/* ── Empty states ── */}
      {showEmptyAfterSearch && (
        <div className="text-center py-16 text-gray-400">
          <p className="text-4xl mb-3">🔍</p>
          <p className="font-medium text-gray-500">No results found</p>
          <p className="text-sm mt-1">Try a different query or remove filters</p>
        </div>
      )}
      {showInitialState && (
        <div className="text-center py-16 text-gray-400">
          <p className="text-4xl mb-3">💍</p>
          <p className="font-medium text-gray-500">Search your jewelry catalog</p>
          <p className="text-sm mt-1">Try "rose gold ring" or "marquise earrings"</p>
        </div>
      )}
    </div>
  );
}

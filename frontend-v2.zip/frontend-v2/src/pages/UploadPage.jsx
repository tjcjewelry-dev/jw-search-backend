import useJewelryStore from '../store/useJewelryStore.js';
import UploadZone from '../components/UploadZone.jsx';
import PreviewCard from '../components/PreviewCard.jsx';

export default function UploadPage() {
  const { queue, isUploading, uploadProgress, uploadAll, clearQueue } = useJewelryStore((s) => ({
    queue:          s.queue,
    isUploading:    s.isUploading,
    uploadProgress: s.uploadProgress,
    uploadAll:      s.uploadAll,
    clearQueue:     s.clearQueue,
  }));

  const pending = queue.filter((i) => i.status === 'pending').length;
  const done    = queue.filter((i) => i.status === 'done').length;
  const errors  = queue.filter((i) => i.status === 'error').length;
  const allDone = queue.length > 0 && queue.every((i) => i.status === 'done' || i.status === 'error');

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Add Jewelry</h1>
        <p className="text-gray-500 text-sm mt-1">
          Drop images below — GPT-4o Mini will auto-tag each one before storing in Pinecone.
        </p>
      </div>

      {/* Drop zone */}
      <UploadZone />

      {/* Queue toolbar */}
      {queue.length > 0 && (
        <div className="flex items-center justify-between bg-white rounded-xl border border-gray-100 shadow-sm px-4 py-3">
          <div className="flex items-center gap-4 text-sm">
            <span className="text-gray-600 font-medium">{queue.length} image{queue.length !== 1 ? 's' : ''}</span>
            {pending > 0   && <span className="badge bg-gray-100 text-gray-600">{pending} pending</span>}
            {done > 0      && <span className="badge bg-green-100 text-green-700">✓ {done} done</span>}
            {errors > 0    && <span className="badge bg-red-100 text-red-600">✗ {errors} failed</span>}
          </div>

          <div className="flex items-center gap-3">
            {/* Progress bar */}
            {isUploading && (
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <div className="w-32 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full transition-all duration-300"
                    style={{ width: `${(uploadProgress.current / uploadProgress.total) * 100}%` }}
                  />
                </div>
                <span>{uploadProgress.current}/{uploadProgress.total}</span>
              </div>
            )}

            {allDone ? (
              <button onClick={clearQueue} className="btn-ghost text-sm">Clear All</button>
            ) : (
              <>
                <button onClick={clearQueue} disabled={isUploading} className="btn-ghost text-sm">Clear</button>
                <button
                  onClick={uploadAll}
                  disabled={isUploading || pending === 0}
                  className="btn-gold text-sm"
                >
                  {isUploading
                    ? `Processing ${uploadProgress.current} of ${uploadProgress.total}…`
                    : `Add ${pending} to Catalog`}
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Image grid */}
      {queue.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {queue.map((item) => (
            <PreviewCard key={item.id} item={item} />
          ))}
        </div>
      )}

      {/* Empty state */}
      {queue.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          <p className="text-4xl mb-3">💎</p>
          <p className="font-medium text-gray-500">No images queued</p>
          <p className="text-sm mt-1">Drop jewelry images above to get started</p>
        </div>
      )}
    </div>
  );
}

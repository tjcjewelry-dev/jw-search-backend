/**
 * TrainingPage — teach the AI your visual vocabulary.
 *
 * Lessons are few-shot examples sent to GPT-4o Mini BEFORE every new tagging call.
 * The more precise your lessons, the better the AI tags similar images.
 *
 * Good lessons to add:
 *   • A "Miracle Plate" ring → settingStyle: "Miracle Plate"
 *   • A rose gold piece that looks two-tone → metalColor: "Rose Gold"
 *   • An item with rhodium plating → hasRhodium: true
 *   • A specific stone cut your catalog uses heavily
 */
import { useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import useTrainingStore from '../store/useTrainingStore.js';
import LessonCard from '../components/LessonCard.jsx';

const TAG_FIELDS = [
  { key: 'category',     label: 'Category',
    opts: ['Ring','Earring','Pendant','Bracelet','Bangle','Necklace','Brooch','Anklet','Nose Pin'] },
  { key: 'metalColor',   label: 'Metal Color',
    opts: ['Yellow Gold','White Gold','Rose Gold','Two Tone','Tri Color','Platinum','Sterling Silver'] },
  { key: 'settingStyle', label: 'Setting Style',
    opts: ['Solitaire','Halo','Double Halo','Pave','Side Stone','Three-Stone','Bezel',
           'Vintage','Milgrain','Filigree','Cluster','Cathedral','Basket','Flush',
           'Eternity','Half-Eternity','Hidden Halo','Scalloped','Trellis','Shared-Prong','Illusion'] },
  { key: 'prong',        label: 'Prong Type',
    opts: ['4 Prong','6 Prong','V Prong','Bezel','Half Bezel','Channel','Pave','Bar Set',
           'Burnish','Tension','Shared Prong','Micro-Pave','French Set','Fishtail','Scalloped'] },
  { key: 'shank',        label: 'Shank Style',
    opts: ['Plain','Split Shank','Twisted','Knife Edge','Milgrain','Comfort Fit',
           'Wide Band','Tapered','Bypass','Cathedral','Euro-Shank','Floral'] },
  { key: 'stoneShapes',  label: 'Stone Shapes', isArray: true,
    opts: ['ROUND','PEAR','OVAL','MARQUISE','PRINCESS','CUSHION','EMERALD','RADIANT',
           'HEART','BAGUETTE','ASCHER','HEXAGON','KITE','Trillion','HALF MOON',
           'ELONGATED PEAR','ELONGATED MARQUISE','ELONGATED OVAL'] },
  { key: 'gemstone',     label: 'Gemstone',
    opts: ['Diamond','Ruby','Sapphire','Emerald','Topaz','Amethyst','Citrine',
           'Garnet','Morganite','Opal','Pearl','Tanzanite','Aquamarine'] },
  { key: 'diamondColor', label: 'Diamond Color',
    opts: ['White','Yellow','Champagne','Black','Pink','Blue','Green','Salt and Pepper'] },
  { key: 'hasRhodium',   label: 'Rhodium Plated', opts: ['Yes','No'] },
];

const Spinner = () => (
  <svg className="animate-spin w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
  </svg>
);

// ─── Create Form ─────────────────────────────────────────────────────────────
function CreateLessonForm({ onClose }) {
  const { addLesson, isSaving } = useTrainingStore((s) => ({
    addLesson: s.addLesson,
    isSaving:  s.isSaving,
  }));

  const [file,    setFile]    = useState(null);
  const [preview, setPreview] = useState(null);
  const [name,    setName]    = useState('');
  const [desc,    setDesc]    = useState('');
  const [tags,    setTags]    = useState({});
  const [error,   setError]   = useState(null);
  const [success, setSuccess] = useState(null);

  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    accept:   { 'image/*': ['.jpg','.jpeg','.png','.webp'] },
    multiple: false,
    maxSize:  20 * 1024 * 1024,
    onDropAccepted: ([f]) => {
      if (preview) URL.revokeObjectURL(preview);
      setFile(f);
      setPreview(URL.createObjectURL(f));
      setError(null);
    },
    onDropRejected: () => setError('Only JPG, PNG, WEBP up to 20MB'),
  });

  const setTag = (key, val, isArray) => {
    setTags((prev) => {
      if (!val) { const n = { ...prev }; delete n[key]; return n; }
      if (isArray)              return { ...prev, [key]: [val] };
      if (key === 'hasRhodium') return { ...prev, hasRhodium: val === 'Yes' };
      return { ...prev, [key]: val };
    });
  };

  const handleSubmit = async () => {
    if (!file)        { setError('Please upload a training image'); return; }
    if (!name.trim()) { setError('Lesson name is required'); return; }
    setError(null);
    try {
      const lesson = await addLesson({ file, name: name.trim(), description: desc.trim(), tags });
      setSuccess(`Lesson "${lesson.name}" saved! The AI will use it when tagging new images.`);
      // Reset form
      setFile(null);
      if (preview) URL.revokeObjectURL(preview);
      setPreview(null);
      setName('');
      setDesc('');
      setTags({});
      setTimeout(() => { setSuccess(null); onClose?.(); }, 2500);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="card p-5 space-y-5 border-amber-200 bg-gradient-to-b from-amber-50/60 to-white">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-bold text-gray-900">Add Training Lesson</h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Upload an example image and set its correct tags. The AI learns from this.
          </p>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-lg leading-none">✕</button>
      </div>

      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-4 py-3 flex items-center gap-2">
          <span>✓</span> {success}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3">
          ⚠️ {error}
        </div>
      )}

      {/* Two-column layout: image left, fields right */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

        {/* Left: image + name + description */}
        <div className="space-y-4">
          {/* Drop zone */}
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-2xl transition-all cursor-pointer
              ${isDragReject ? 'border-red-400 bg-red-50'
                : isDragActive ? 'border-amber-400 bg-amber-50 scale-[1.01]'
                : 'border-gray-200 hover:border-amber-300 hover:bg-amber-50/40'}
            `}
          >
            <input {...getInputProps()} />
            {preview ? (
              <div className="relative">
                <img src={preview} alt="Training" className="w-full aspect-square object-cover rounded-2xl" />
                <div className="absolute inset-0 flex items-end justify-center pb-3 opacity-0 hover:opacity-100 transition-opacity">
                  <span className="bg-black/60 text-white text-xs px-3 py-1 rounded-full">
                    Drop another image to replace
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3 py-12 px-4 text-center">
                <div className="w-14 h-14 rounded-full bg-white shadow-sm border border-gray-100 flex items-center justify-center text-2xl">
                  🎓
                </div>
                <div>
                  <p className="font-semibold text-gray-700">Drop your training image</p>
                  <p className="text-xs text-gray-400 mt-1">JPG, PNG, WEBP · up to 20MB</p>
                </div>
              </div>
            )}
          </div>

          {/* Name */}
          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1.5">
              Lesson Name <span className="text-red-400">*</span>
            </label>
            <input
              className="input"
              placeholder="e.g. Miracle Plate Setting, Rose Gold Two-Tone Ring…"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1.5">
              What to look for
              <span className="text-gray-400 font-normal ml-1">(optional but helps)</span>
            </label>
            <textarea
              className="w-full border border-gray-200 rounded-lg p-2.5 text-sm outline-none
                         focus:border-amber-400 focus:ring-1 focus:ring-amber-100 resize-none"
              rows={3}
              placeholder="Describe the visual detail the AI should learn, e.g. 'small stones flush-set in a flat metal plate surrounding the center stone, creating a mirror-like reflective border'"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            />
          </div>
        </div>

        {/* Right: tags */}
        <div className="space-y-3">
          <div>
            <p className="text-xs font-semibold text-gray-700 mb-1.5">Correct Tags for This Image</p>
            <p className="text-xs text-gray-400 leading-snug mb-3">
              Only fill in the tags you want to teach. Leave fields blank if they're not relevant to this lesson.
            </p>
          </div>
          <div className="space-y-2">
            {TAG_FIELDS.map(({ key, label, opts, isArray }) => (
              <div key={key} className="flex items-center gap-2">
                <span className="text-xs text-gray-500 w-28 shrink-0">{label}</span>
                <select
                  className="select text-xs py-1.5 flex-1"
                  value={
                    isArray ? (Array.isArray(tags[key]) ? tags[key][0] : '')
                    : key === 'hasRhodium' ? (tags[key] === true ? 'Yes' : tags[key] === false ? 'No' : '')
                    : (tags[key] || '')
                  }
                  onChange={(e) => setTag(key, e.target.value, isArray)}
                >
                  <option value="">— not set —</option>
                  {opts.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            ))}
          </div>

          {/* Summary of what will be taught */}
          {Object.keys(tags).length > 0 && (
            <div className="bg-amber-50 rounded-xl p-3 border border-amber-100">
              <p className="text-xs font-semibold text-amber-800 mb-1.5">Teaching the AI:</p>
              <div className="flex flex-wrap gap-1">
                {Object.entries(tags)
                  .filter(([, v]) => v !== null && v !== undefined)
                  .map(([k, v]) => {
                    const field = TAG_FIELDS.find((f) => f.key === k);
                    const display = Array.isArray(v) ? v.join(', ') : v === true ? '✓' : String(v);
                    return (
                      <span key={k} className="inline-flex items-center gap-1 bg-white border border-amber-200 rounded-full px-2 py-0.5 text-xs">
                        <span className="text-amber-600 font-medium">{field?.label || k}:</span>
                        <span className="text-gray-700">{display}</span>
                      </span>
                    );
                  })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Submit */}
      <div className="flex gap-3 pt-2 border-t border-gray-100">
        <button
          onClick={handleSubmit}
          disabled={isSaving || !file || !name.trim()}
          className="btn-gold flex items-center gap-2 px-6"
        >
          {isSaving && <Spinner />}
          {isSaving ? 'Saving lesson…' : 'Save Lesson'}
        </button>
        <button onClick={onClose} className="btn-ghost">Cancel</button>
        <p className="text-xs text-gray-400 self-center ml-auto">
          This lesson will be used for all future image tagging.
        </p>
      </div>
    </div>
  );
}

// ─── How it works banner ──────────────────────────────────────────────────────
function HowItWorks({ onDismiss }) {
  return (
    <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-5">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-3">
          <p className="font-semibold text-amber-900">How AI Training Works</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-amber-800">
            <div className="flex gap-2">
              <span className="text-lg shrink-0">📸</span>
              <div>
                <p className="font-medium">1. Upload an example</p>
                <p className="text-amber-700">Upload a jewelry image that shows a specific pattern you want the AI to recognize.</p>
              </div>
            </div>
            <div className="flex gap-2">
              <span className="text-lg shrink-0">🏷️</span>
              <div>
                <p className="font-medium">2. Set correct tags</p>
                <p className="text-amber-700">Tell the AI exactly what tags this image should get. Be specific — this becomes its reference.</p>
              </div>
            </div>
            <div className="flex gap-2">
              <span className="text-lg shrink-0">🤖</span>
              <div>
                <p className="font-medium">3. AI learns instantly</p>
                <p className="text-amber-700">Every future upload sends your lessons as examples. The AI applies them to similar images automatically.</p>
              </div>
            </div>
          </div>
          <p className="text-xs text-amber-700 bg-amber-100/60 rounded-lg px-3 py-2">
            💡 <strong>Best results:</strong> Add 3–5 lessons per visual pattern. Prioritize things the AI consistently gets wrong — uncommon settings, ambiguous metal colors, or proprietary design names.
          </p>
        </div>
        <button onClick={onDismiss} className="text-amber-400 hover:text-amber-600 shrink-0 text-lg">✕</button>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function TrainingPage() {
  const { lessons, lessonCount, isLoading, error, loadLessons } = useTrainingStore((s) => ({
    lessons:     s.lessons,
    lessonCount: s.lessonCount,
    isLoading:   s.isLoading,
    error:       s.error,
    loadLessons: s.loadLessons,
  }));

  const [showForm,   setShowForm]   = useState(false);
  const [showHowTo,  setShowHowTo]  = useState(true);

  useEffect(() => { loadLessons(); }, []);

  return (
    <div className="max-w-5xl mx-auto space-y-6">

      {/* ── Page header ── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-900">AI Training</h1>
            {lessonCount > 0 && (
              <span className="bg-amber-100 text-amber-800 text-xs font-semibold px-2.5 py-1 rounded-full">
                {lessonCount} lesson{lessonCount !== 1 ? 's' : ''} active
              </span>
            )}
          </div>
          <p className="text-gray-500 text-sm mt-1">
            Teach the AI your specific visual vocabulary — settings, metals, stone cuts.
          </p>
        </div>
        <button
          onClick={() => { setShowForm((x) => !x); setShowHowTo(false); }}
          className={`btn-gold flex items-center gap-2 ${showForm ? 'opacity-0 pointer-events-none' : ''}`}
        >
          <span>+</span> Add Lesson
        </button>
      </div>

      {/* ── How it works ── */}
      {showHowTo && !showForm && lessonCount === 0 && (
        <HowItWorks onDismiss={() => setShowHowTo(false)} />
      )}

      {/* ── Create form ── */}
      {showForm && (
        <CreateLessonForm onClose={() => setShowForm(false)} />
      )}

      {/* ── Error ── */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3">
          ⚠️ {error}
        </div>
      )}

      {/* ── Lessons list ── */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20 gap-3 text-gray-400">
          <Spinner /> Loading lessons…
        </div>
      ) : lessons.length > 0 ? (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-600">
              {lessons.length} lesson{lessons.length !== 1 ? 's' : ''} —
              the AI sees up to 6 most recent when tagging new images
            </p>
            <button
              onClick={() => setShowForm(true)}
              className="text-sm text-amber-600 hover:text-amber-700 font-medium"
            >
              + Add another
            </button>
          </div>

          <div className="space-y-3">
            {lessons.map((lesson, i) => (
              <div key={lesson.id} className="relative">
                {/* Active indicator for top 6 */}
                {i < 6 && (
                  <div className="absolute -left-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-amber-400 shadow-sm" />
                )}
                <LessonCard lesson={lesson} />
                {i === 5 && lessons.length > 6 && (
                  <div className="text-xs text-gray-400 text-center py-1">
                    ↑ Active (sent to AI) · ↓ Inactive (stored but not used until you delete newer ones)
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      ) : !showForm && (
        /* ── Empty state ── */
        <div className="text-center py-20">
          <div className="w-20 h-20 rounded-2xl bg-amber-50 border-2 border-dashed border-amber-200
            flex items-center justify-center text-3xl mx-auto mb-4">
            🎓
          </div>
          <p className="font-semibold text-gray-700 text-lg">No lessons yet</p>
          <p className="text-gray-500 text-sm mt-1 max-w-sm mx-auto">
            Add your first lesson to start teaching the AI your specific visual patterns and terminology.
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="btn-gold mt-6 px-8"
          >
            Add First Lesson
          </button>
        </div>
      )}
    </div>
  );
}

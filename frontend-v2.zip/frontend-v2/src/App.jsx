import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import UploadPage from './pages/UploadPage.jsx';
import SearchPage from './pages/SearchPage.jsx';
import TrainingPage from './pages/TrainingPage.jsx';

export default function App() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="px-8 py-8">
          <Routes>
            <Route path="/"         element={<SearchPage />} />
            <Route path="/upload"   element={<UploadPage />} />
            <Route path="/training" element={<TrainingPage />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

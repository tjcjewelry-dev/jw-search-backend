/**
 * API Client
 *
 * In development: VITE_API_URL is empty → axios uses relative URLs → Vite proxy
 *                 forwards /api/* to http://localhost:3001
 *
 * In production:  VITE_API_URL = https://your-app.up.railway.app
 *                 axios calls the Railway backend directly (full URL, no proxy needed)
 */
import axios from 'axios';

const BASE = import.meta.env.VITE_API_URL
  ? `${import.meta.env.VITE_API_URL}/api/jewelry`
  : '/api/jewelry';

const api = axios.create({ baseURL: BASE });

export async function uploadImage({ file, sku, imageUrl, autoTag, tags }) {
  const form = new FormData();
  form.append('image',   file);
  form.append('autoTag', String(autoTag ?? true));
  if (sku)      form.append('sku',      sku);
  if (imageUrl) form.append('imageUrl', imageUrl);
  if (tags && Object.keys(tags).length) form.append('tags', JSON.stringify(tags));
  const { data } = await api.post('/upload', form);
  return data;
}

export async function searchText({ query, filter, minScore }) {
  const { data } = await api.post('/search', {
    query,
    filter:   filter   || undefined,
    minScore: minScore ?? undefined,
  });
  return data;
}

export async function searchByImageApi({ file }) {
  const form = new FormData();
  form.append('image', file);
  const { data } = await api.post('/search-image', form);
  return data;
}

export async function findSimilarApi({ id }) {
  const { data } = await api.get(`/similar/${id}`);
  return data;
}

export async function fetchStats() {
  const { data } = await api.get('/stats');
  return data;
}

export async function deleteItemApi(id) {
  const { data } = await api.delete(`/${id}`);
  return data;
}


export async function editProductTag(id, userPrompt) {
  const { data } = await api.put(`/edit/${id}`, { userPrompt });
  // Backend now returns { success, result } — result is the formatted record
  return data.result;
}

export async function bulkEditProductTags(ids, userPrompt) {
  const { data } = await api.put('/bulk-edit', { ids, userPrompt });
  return data; // { results, succeeded, failed }
}

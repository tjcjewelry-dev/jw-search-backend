/**
 * Training API Client
 * Talks to /api/training/* on the Express backend.
 */
import axios from 'axios';

const BASE = import.meta.env.VITE_API_URL
  ? `${import.meta.env.VITE_API_URL}/api/training`
  : '/api/training';

const api = axios.create({ baseURL: BASE });

/** List all lessons (no base64 — display only) */
export async function fetchLessons() {
  const { data } = await api.get('/lessons');
  return data; // { lessons, total }
}

/** Get lesson count */
export async function fetchLessonCount() {
  const { data } = await api.get('/lessons/count');
  return data.count;
}

/**
 * Create a lesson.
 * @param {{ file, name, description, tags }} opts
 */
export async function createLesson({ file, name, description, tags }) {
  const form = new FormData();
  form.append('image',       file);
  form.append('name',        name);
  if (description) form.append('description', description);
  if (tags && Object.keys(tags).length) form.append('tags', JSON.stringify(tags));
  const { data } = await api.post('/lessons', form);
  return data; // { success, lesson, message }
}

/**
 * Update a lesson (name, description, tags, optionally a new image).
 */
export async function updateLesson(id, { file, name, description, tags }) {
  const form = new FormData();
  if (file)        form.append('image',       file);
  if (name)        form.append('name',        name);
  if (description != null) form.append('description', description);
  if (tags)        form.append('tags',        JSON.stringify(tags));
  const { data } = await api.put(`/lessons/${id}`, form);
  return data; // { success, lesson }
}

/** Delete a lesson */
export async function deleteLesson(id) {
  const { data } = await api.delete(`/lessons/${id}`);
  return data;
}

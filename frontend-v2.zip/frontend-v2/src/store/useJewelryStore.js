/**
 * Zustand store
 *
 * Key additions in this version:
 *   - selectedIds    : Set of result IDs the user has checked for bulk edit
 *   - editTag        : re-tags a single item and patches it in allResults
 *   - bulkEditTags   : applies one prompt to all selected items in sequence,
 *                      updating each card live as it completes
 *   - editingIds     : Set of IDs currently being processed (for per-card spinners)
 */
import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import {
  uploadImage,
  searchText,
  searchByImageApi,
  findSimilarApi,
  fetchStats,
  deleteItemApi,
  editProductTag,
  bulkEditProductTags,
} from '../api/jewelry.api.js';

const PAGE_SIZE = 12;

const useJewelryStore = create((set, get) => ({

  // ─── Upload ────────────────────────────────────────────────────────────────
  queue:          [],
  isUploading:    false,
  uploadProgress: { current: 0, total: 0 },

  addToQueue: (files) => {
    const items = files.map((file) => ({
      id:       uuidv4(),
      file,
      preview:  URL.createObjectURL(file),
      sku:      '',
      imageUrl: '',
      autoTag:  true,
      tags:     {},
      status:   'pending',
      result:   null,
      error:    null,
    }));
    set((s) => ({ queue: [...s.queue, ...items] }));
  },

  removeFromQueue: (id) => {
    set((s) => {
      const item = s.queue.find((i) => i.id === id);
      if (item?.preview) URL.revokeObjectURL(item.preview);
      return { queue: s.queue.filter((i) => i.id !== id) };
    });
  },

  updateQueueItem: (id, patch) =>
    set((s) => ({ queue: s.queue.map((i) => (i.id === id ? { ...i, ...patch } : i)) })),

  clearQueue: () => {
    get().queue.forEach((i) => { if (i.preview) URL.revokeObjectURL(i.preview); });
    set({ queue: [], uploadProgress: { current: 0, total: 0 } });
  },

  uploadAll: async () => {
    const pending = get().queue.filter((i) => i.status === 'pending');
    if (!pending.length) return;

    set({ isUploading: true, uploadProgress: { current: 0, total: pending.length } });

    for (let idx = 0; idx < pending.length; idx++) {
      const item = pending[idx];
      get().updateQueueItem(item.id, { status: 'uploading' });
      set({ uploadProgress: { current: idx + 1, total: pending.length } });
      try {
        const result = await uploadImage({
          file:     item.file,
          sku:      item.sku     || undefined,
          imageUrl: item.imageUrl || undefined,
          autoTag:  item.autoTag,
          tags:     item.tags,
        });
        get().updateQueueItem(item.id, { status: 'done', result });
      } catch (err) {
        const msg = err.response?.data?.error || err.message;
        get().updateQueueItem(item.id, { status: 'error', error: msg });
      }
    }

    set({ isUploading: false });
    get().fetchStats();
  },

  // ─── Search ────────────────────────────────────────────────────────────────
  searchMode:    'text',
  searchQuery:   '',
  searchLabel:   '',
  searchFilters: {},

  allResults:     [],
  displayedCount: PAGE_SIZE,
  PAGE_SIZE,

  isSearching: false,
  searchError: null,

  searchImageFile:    null,
  searchImagePreview: null,

  searchResults: () => {
    const { allResults, displayedCount } = get();
    return allResults.slice(0, displayedCount);
  },

  hasMore: () => {
    const { allResults, displayedCount } = get();
    return displayedCount < allResults.length;
  },

  loadMore: () => set((s) => ({ displayedCount: s.displayedCount + PAGE_SIZE })),

  setSearchMode: (mode) => set({
    searchMode:     mode,
    allResults:     [],
    displayedCount: PAGE_SIZE,
    searchError:    null,
    searchLabel:    '',
    selectedIds:    new Set(),
  }),

  setSearchQuery:  (q) => set({ searchQuery: q }),

  setSearchFilter: (key, val) =>
    set((s) => {
      const isEmpty = !val || (Array.isArray(val) && val.length === 0);
      if (isEmpty) {
        const f = { ...s.searchFilters };
        delete f[key];
        return { searchFilters: f };
      }
      return { searchFilters: { ...s.searchFilters, [key]: val } };
    }),

  clearFilters: () => set({ searchFilters: {} }),

  setSearchImage: (file) => {
    const prev = get().searchImagePreview;
    if (prev) URL.revokeObjectURL(prev);
    set({
      searchImageFile:    file,
      searchImagePreview: file ? URL.createObjectURL(file) : null,
      allResults:         [],
      displayedCount:     PAGE_SIZE,
      searchError:        null,
      searchLabel:        '',
      selectedIds:        new Set(),
    });
  },

  search: async () => {
    const { searchMode, searchQuery, searchFilters, searchImageFile } = get();
    set({
      isSearching:    true,
      searchError:    null,
      allResults:     [],
      displayedCount: PAGE_SIZE,
      selectedIds:    new Set(),
    });
    try {
      let data;
      if (searchMode === 'image' && searchImageFile) {
        data = await searchByImageApi({ file: searchImageFile });
        set({ searchLabel: `Image search — ${data.total} results` });
      } else {
        const filter = Object.keys(searchFilters).length ? searchFilters : undefined;
        data = await searchText({ query: searchQuery, filter });
        set({ searchLabel: `"${searchQuery}" — ${data.total} results` });
      }
      set({ allResults: data.results });
    } catch (err) {
      set({ searchError: err.response?.data?.error || err.message });
    } finally {
      set({ isSearching: false });
    }
  },

  findSimilar: async (id) => {
    set({
      isSearching:    true,
      searchError:    null,
      allResults:     [],
      displayedCount: PAGE_SIZE,
      searchMode:     'text',
      selectedIds:    new Set(),
    });
    try {
      const data = await findSimilarApi({ id });
      set({
        allResults:  data.results,
        searchQuery: '',
        searchLabel: `Similar to: ${id} — ${data.total} results`,
      });
    } catch (err) {
      set({ searchError: err.response?.data?.error || err.message });
    } finally {
      set({ isSearching: false });
    }
  },

  deleteItem: async (id) => {
    await deleteItemApi(id);
    set((s) => {
      const next = new Set(s.selectedIds);
      next.delete(id);
      return {
        allResults:  s.allResults.filter((r) => r.id !== id),
        selectedIds: next,
      };
    });
    get().fetchStats();
  },

  // ─── Selection (for bulk edit) ────────────────────────────────────────────
  selectedIds: new Set(),   // Set<string>
  selectMode:  false,       // true = selection UI is active

  toggleSelectMode: () =>
    set((s) => ({
      selectMode:  !s.selectMode,
      selectedIds: new Set(),   // clear selection when toggling off
    })),

  toggleSelectId: (id) =>
    set((s) => {
      const next = new Set(s.selectedIds);
      next.has(id) ? next.delete(id) : next.add(id);
      return { selectedIds: next };
    }),

  selectAll: () =>
    set((s) => ({
      selectedIds: new Set(s.allResults.slice(0, s.displayedCount).map((r) => r.id)),
    })),

  clearSelection: () => set({ selectedIds: new Set() }),

  // ─── Edit (single) ────────────────────────────────────────────────────────
  // editingIds tracks which cards are currently being re-tagged (for spinners)
  editingIds: new Set(),

  editTag: async (id, prompt) => {
    // Mark this card as editing
    set((s) => {
      const next = new Set(s.editingIds);
      next.add(id);
      return { editingIds: next };
    });
    try {
      const updated = await editProductTag(id, prompt);
      if (updated) {
        // Patch the result in-place inside allResults so the card re-renders
        set((s) => ({
          allResults: s.allResults.map((r) => (r.id === id ? { ...r, ...updated } : r)),
        }));
      }
      return updated;
    } catch (err) {
      throw err;
    } finally {
      set((s) => {
        const next = new Set(s.editingIds);
        next.delete(id);
        return { editingIds: next };
      });
    }
  },

  // ─── Bulk Edit ────────────────────────────────────────────────────────────
  isBulkEditing:     false,
  bulkEditProgress:  { current: 0, total: 0 },
  bulkEditError:     null,

  bulkEditTags: async (prompt) => {
    const { selectedIds } = get();
    const ids = [...selectedIds];
    if (!ids.length || !prompt?.trim()) return;

    set({
      isBulkEditing:    true,
      bulkEditError:    null,
      bulkEditProgress: { current: 0, total: ids.length },
    });

    // Process one at a time so each card updates live as it finishes
    for (let i = 0; i < ids.length; i++) {
      const id = ids[i];
      set((s) => {
        const next = new Set(s.editingIds);
        next.add(id);
        return {
          editingIds:       next,
          bulkEditProgress: { current: i + 1, total: ids.length },
        };
      });

      try {
        const updated = await editProductTag(id, prompt.trim());
        if (updated) {
          set((s) => ({
            allResults: s.allResults.map((r) => (r.id === id ? { ...r, ...updated } : r)),
          }));
        }
      } catch (err) {
        console.error(`[BulkEdit] ${id}:`, err.message);
        // Don't abort — continue with remaining items
      } finally {
        set((s) => {
          const next = new Set(s.editingIds);
          next.delete(id);
          return { editingIds: next };
        });
      }
    }

    set({
      isBulkEditing: false,
      selectedIds:   new Set(),
      selectMode:    false,
    });
  },

  // ─── Extract / Download selected images ──────────────────────────────────
  isExtracting: false,

  extractImages: async () => {
    const { selectedIds, allResults } = get();
    const ids = [...selectedIds];
    if (!ids.length) return;

    const selected = allResults.filter((r) => ids.includes(r.id));
    set({ isExtracting: true });

    // Route all image fetches through the backend download proxy.
    // This avoids browser CORS errors when the CDN (e.g. tjc.me) does not
    // send Access-Control-Allow-Origin headers.
    // The server fetches the image (no CORS constraint server-side) and
    // streams it back to the browser as an attachment.
    const proxyUrl = (imageUrl) => {
      const base = import.meta.env.VITE_API_URL
        ? `${import.meta.env.VITE_API_URL}/api/jewelry`
        : '/api/jewelry';
      return `${base}/download-proxy?url=${encodeURIComponent(imageUrl)}`;
    };

    try {
      if (selected.length === 1) {
        // Single image — fetch via proxy, download directly
        const r        = selected[0];
        const response = await fetch(proxyUrl(r.imageUrl));
        if (!response.ok) throw new Error(`Server returned ${response.status}`);
        const blob = await response.blob();
        const ext  = r.imageUrl.split('.').pop().split('?')[0] || 'jpg';
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href     = url;
        a.download = `${r.sku || r.id}.${ext}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } else {
        // Multiple images — fetch all via proxy, bundle into ZIP
        const JSZip = (await import('jszip')).default;
        const zip   = new JSZip();
        const errors = [];

        // Fetch sequentially to avoid hammering the proxy with 100+ concurrent requests
        for (const r of selected) {
          try {
            const response = await fetch(proxyUrl(r.imageUrl));
            if (!response.ok) throw new Error(`${response.status}`);
            const blob = await response.blob();
            const ext  = r.imageUrl.split('.').pop().split('?')[0] || 'jpg';
            zip.file(`${r.sku || r.id}.${ext}`, blob);
          } catch (err) {
            errors.push(`${r.sku || r.id}: ${err.message}`);
            console.warn(`[Extract] Failed for ${r.sku}:`, err.message);
          }
        }

        // Include a log of any failures so the user knows what was skipped
        if (errors.length > 0) {
          zip.file('_download-errors.txt', errors.join('
'));
        }

        const zipBlob = await zip.generateAsync({ type: 'blob' });
        const url     = URL.createObjectURL(zipBlob);
        const a       = document.createElement('a');
        a.href        = url;
        a.download    = `jewelry-export-${Date.now()}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (err) {
      console.error('[Extract] Failed:', err.message);
    } finally {
      set({ isExtracting: false });
    }
  },

  // ─── Stats ────────────────────────────────────────────────────────────────
  stats: null,
  fetchStats: async () => {
    try {
      const stats = await fetchStats();
      set({ stats });
    } catch {}
  },
}));

export default useJewelryStore;

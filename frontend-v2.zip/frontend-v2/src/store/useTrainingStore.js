/**
 * Training Store — manages AI lesson state.
 *
 * Lessons teach the AI visual patterns:
 *   "this setting style is Miracle Plate"
 *   "this metal is Rose Gold even though it looks Two Tone"
 *
 * The backend stores lessons as JSON + compressed base64 images.
 * This store handles CRUD and exposes derived state for the UI.
 */
import { create } from 'zustand';
import {
  fetchLessons,
  fetchLessonCount,
  createLesson,
  updateLesson,
  deleteLesson,
} from '../api/training.api.js';

const useTrainingStore = create((set, get) => ({
  lessons:      [],
  lessonCount:  0,
  isLoading:    false,
  isSaving:     false,
  error:        null,

  // ─── Load ───────────────────────────────────────────────────────────────
  loadLessons: async () => {
    set({ isLoading: true, error: null });
    try {
      const data = await fetchLessons();
      set({ lessons: data.lessons, lessonCount: data.total });
    } catch (err) {
      set({ error: err.response?.data?.error || err.message });
    } finally {
      set({ isLoading: false });
    }
  },

  loadLessonCount: async () => {
    try {
      const count = await fetchLessonCount();
      set({ lessonCount: count });
    } catch {}
  },

  // ─── Create ──────────────────────────────────────────────────────────────
  addLesson: async ({ file, name, description, tags }) => {
    set({ isSaving: true, error: null });
    try {
      const data = await createLesson({ file, name, description, tags });
      set((s) => ({
        lessons:     [data.lesson, ...s.lessons],
        lessonCount: s.lessonCount + 1,
      }));
      return data.lesson;
    } catch (err) {
      const msg = err.response?.data?.error || err.message;
      set({ error: msg });
      throw new Error(msg);
    } finally {
      set({ isSaving: false });
    }
  },

  // ─── Update ──────────────────────────────────────────────────────────────
  editLesson: async (id, patch) => {
    set({ isSaving: true, error: null });
    try {
      const data = await updateLesson(id, patch);
      set((s) => ({
        lessons: s.lessons.map((l) => (l.id === id ? data.lesson : l)),
      }));
      return data.lesson;
    } catch (err) {
      const msg = err.response?.data?.error || err.message;
      set({ error: msg });
      throw new Error(msg);
    } finally {
      set({ isSaving: false });
    }
  },

  // ─── Delete ──────────────────────────────────────────────────────────────
  removeLesson: async (id) => {
    try {
      await deleteLesson(id);
      set((s) => ({
        lessons:     s.lessons.filter((l) => l.id !== id),
        lessonCount: Math.max(0, s.lessonCount - 1),
      }));
    } catch (err) {
      set({ error: err.response?.data?.error || err.message });
    }
  },

  clearError: () => set({ error: null }),
}));

export default useTrainingStore;

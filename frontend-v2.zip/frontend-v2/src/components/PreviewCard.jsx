import { useState } from 'react';
import useJewelryStore from '../store/useJewelryStore.js';

const CATEGORIES = ['Ring', 'Earring', 'Pendant', 'Bracelet', 'Necklace', 'Bangle', 'Brooch'];
const METALS     = ['Yellow Gold', 'White Gold', 'Rose Gold', 'Two Tone', 'Platinum', 'Sterling Silver'];
const STONES     = ['Round', 'Marquise', 'Princess', 'Oval', 'Pear', 'Cushion', 'Emerald', 'Heart', 'Baguette'];
const GEMSTONES  = ['Diamond', 'Ruby', 'Sapphire', 'Emerald', 'Topaz', 'Amethyst', 'Citrine', 'Garnet', 'Morganite', 'Opal'];

const StatusBadge = ({ status, error }) => {
  const map = {
    pending:   { cls: 'bg-gray-100 text-gray-500',   label: 'Pending' },
    uploading: { cls: 'bg-blue-100 text-blue-600',   label: 'Processing…' },
    done:      { cls: 'bg-green-100 text-green-700', label: '✓ Done' },
    error:     { cls: 'bg-red-100 text-red-600',     label: '✗ Error' },
  };
  const { cls, label } = map[status] || map.pending;
  return (
    <span className={`badge ${cls}`} title={error || ''}>
      {status === 'uploading' && (
        <svg className="animate-spin w-3 h-3 mr-1" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
        </svg>
      )}
      {label}
    </span>
  );
};

export default function PreviewCard({ item }) {
  const { updateQueueItem, removeFromQueue, isUploading } = useJewelryStore((s) => ({
    updateQueueItem: s.updateQueueItem,
    removeFromQueue: s.removeFromQueue,
    isUploading:     s.isUploading,
  }));

  const [expanded, setExpanded] = useState(false);
  const isDone = item.status === 'done';
  const isActive = item.status === 'uploading';

  const update = (patch) => updateQueueItem(item.id, patch);
  const setTag = (key, val) => update({ tags: { ...item.tags, [key]: val || undefined } });

  return (
    <div className={`card overflow-hidden transition-all duration-200 ${isActive ? 'ring-2 ring-amber-400' : ''} ${isDone ? 'opacity-80' : ''}`}>
      {/* Image */}
      <div className="relative aspect-square bg-gray-100 overflow-hidden">
        <img
          src={item.preview}
          alt={item.file.name}
          className="w-full h-full object-cover"
        />
        {/* Status overlay */}
        <div className="absolute top-2 right-2">
          <StatusBadge status={item.status} error={item.error} />
        </div>
        {/* Done checkmark overlay */}
        {isDone && (
          <div className="absolute inset-0 bg-green-500/10 flex items-center justify-center">
            <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white text-lg font-bold shadow-lg">
              ✓
            </div>
          </div>
        )}
        {/* Remove button */}
        {!isUploading && item.status !== 'done' && (
          <button
            onClick={() => removeFromQueue(item.id)}
            className="absolute top-2 left-2 w-6 h-6 rounded-full bg-black/50 hover:bg-black/70 text-white text-xs flex items-center justify-center transition-colors"
          >
            ✕
          </button>
        )}
      </div>

      {/* Info */}
      <div className="p-3 space-y-2">
        <p className="text-xs text-gray-500 truncate" title={item.file.name}>{item.file.name}</p>

        {/* Error message */}
        {item.error && (
          <p className="text-xs text-red-500 bg-red-50 rounded p-1.5 leading-snug">{item.error}</p>
        )}

        {/* Result tags (after done) */}
        {isDone && item.result?.tags && (
          <div className="flex flex-wrap gap-1 pt-1">
            {[item.result.tags.category, item.result.tags.metal, item.result.tags.centerStone]
              .filter(Boolean).map((t) => (
                <span key={t} className="badge bg-amber-50 text-amber-700 border border-amber-200">{t}</span>
              ))}
          </div>
        )}

        {/* Fields (only when pending/error) */}
        {!isDone && (
          <>
            {/* SKU */}
            <input
              className="input text-xs py-1.5"
              placeholder="SKU (optional)"
              value={item.sku}
              onChange={(e) => update({ sku: e.target.value })}
              disabled={isActive}
            />

            {/* Quick tags */}
            <div className="grid grid-cols-2 gap-1.5">
              <select className="select text-xs py-1.5" value={item.tags.category || ''} onChange={(e) => setTag('category', e.target.value)} disabled={isActive}>
                <option value="">Category</option>
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
              <select className="select text-xs py-1.5" value={item.tags.metal || ''} onChange={(e) => setTag('metal', e.target.value)} disabled={isActive}>
                <option value="">Metal</option>
                {METALS.map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>

            {/* Advanced toggle */}
            <button
              onClick={() => setExpanded((x) => !x)}
              className="text-xs text-amber-600 hover:text-amber-700 font-medium w-full text-left"
            >
              {expanded ? '▲ Less' : '▼ More tags'}
            </button>

            {expanded && (
              <div className="space-y-1.5">
                <select className="select text-xs py-1.5" value={item.tags.centerStone || ''} onChange={(e) => setTag('centerStone', e.target.value)} disabled={isActive}>
                  <option value="">Center Stone</option>
                  {STONES.map((s) => <option key={s}>{s}</option>)}
                </select>
                <select className="select text-xs py-1.5" value={item.tags.gemstone || ''} onChange={(e) => setTag('gemstone', e.target.value)} disabled={isActive}>
                  <option value="">Gemstone</option>
                  {GEMSTONES.map((g) => <option key={g}>{g}</option>)}
                </select>
                <input
                  className="input text-xs py-1.5"
                  placeholder="CDN URL (optional)"
                  value={item.imageUrl}
                  onChange={(e) => update({ imageUrl: e.target.value })}
                  disabled={isActive}
                />
                {/* Auto-tag toggle */}
                <label className="flex items-center gap-2 cursor-pointer">
                  <div
                    onClick={() => update({ autoTag: !item.autoTag })}
                    className={`w-8 h-4 rounded-full transition-colors relative ${item.autoTag ? 'bg-amber-500' : 'bg-gray-200'}`}
                  >
                    <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all ${item.autoTag ? 'left-4' : 'left-0.5'}`} />
                  </div>
                  <span className="text-xs text-gray-500">AI Auto-tag</span>
                </label>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

import React from 'react';

export default function PageBackdrop({ isLoading }) {
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="h-16 w-16 animate-spin rounded-full border-4 border-gray-300 border-t-blue-500"></div>
      <span className="sr-only">Loading...</span>
    </div>
  );
}
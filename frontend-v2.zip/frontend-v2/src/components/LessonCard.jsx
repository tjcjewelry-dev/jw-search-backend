/**
 * LessonCard — displays one training lesson.
 *
 * States:
 *   - View  : shows thumbnail, name, description, tags, edit + delete buttons
 *   - Edit  : inline form for name, description, tags (image optional re-upload)
 */
import { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import useTrainingStore from '../store/useTrainingStore.js';

const TAG_FIELDS = [
  { key: 'category',     label: 'Category',
    opts: ['Ring','Earring','Pendant','Bracelet','Bangle','Necklace','Brooch','Anklet','Nose Pin'] },
  { key: 'metalColor',   label: 'Metal',
    opts: ['Yellow Gold','White Gold','Rose Gold','Two Tone','Tri Color','Platinum','Sterling Silver'] },
  { key: 'settingStyle', label: 'Setting',
    opts: ['Solitaire','Halo','Double Halo','Pave','Side Stone','Three-Stone','Bezel',
           'Vintage','Milgrain','Filigree','Cluster','Cathedral','Basket','Flush',
           'Eternity','Half-Eternity','Hidden Halo','Scalloped','Trellis','Shared-Prong','Illusion'] },
  { key: 'prong',        label: 'Prong',
    opts: ['4 Prong','6 Prong','V Prong','Bezel','Half Bezel','Channel','Pave','Bar Set',
           'Burnish','Tension','Shared Prong','Micro-Pave','French Set','Fishtail','Scalloped'] },
  { key: 'shank',        label: 'Shank',
    opts: ['Plain','Split Shank','Twisted','Knife Edge','Milgrain','Comfort Fit',
           'Wide Band','Tapered','Bypass','Cathedral','Euro-Shank','Floral'] },
  { key: 'stoneShapes',  label: 'Stone Shapes (pick one)',
    isArray: true,
    opts: ['ROUND','PEAR','OVAL','MARQUISE','PRINCESS','CUSHION','EMERALD','RADIANT',
           'HEART','BAGUETTE','ASCHER','HEXAGON','KITE','Trillion','HALF MOON',
           'ELONGATED PEAR','ELONGATED MARQUISE','ELONGATED OVAL'] },
  { key: 'gemstone',     label: 'Gemstone',
    opts: ['Diamond','Ruby','Sapphire','Emerald','Topaz','Amethyst','Citrine',
           'Garnet','Morganite','Opal','Pearl','Tanzanite','Aquamarine'] },
  { key: 'hasRhodium',   label: 'Rhodium',
    opts: ['Yes','No'] },
];

const Spinner = () => (
  <svg className="animate-spin w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
  </svg>
);

const TagChip = ({ label, color = 'gray' }) => {
  const cls = {
    gray:   'bg-gray-100 text-gray-600',
    amber:  'bg-amber-50 text-amber-700 border border-amber-200',
    blue:   'bg-blue-50 text-blue-600 border border-blue-100',
    green:  'bg-green-50 text-green-700 border border-green-200',
  }[color] || 'bg-gray-100 text-gray-600';
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}>
      {label}
    </span>
  );
};

function getTagColor(key) {
  if (key === 'metalColor')   return 'amber';
  if (key === 'stoneShapes')  return 'blue';
  if (key === 'settingStyle') return 'green';
  return 'gray';
}

export default function LessonCard({ lesson }) {
  const { editLesson, removeLesson, isSaving } = useTrainingStore((s) => ({
    editLesson:   s.editLesson,
    removeLesson: s.removeLesson,
    isSaving:     s.isSaving,
  }));

  const [mode,     setMode]     = useState('view'); // 'view' | 'edit'
  const [imgError, setImgError] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [saveErr,  setSaveErr]  = useState(null);

  // Edit form state — initialised from lesson
  const [name,    setName]    = useState(lesson.name);
  const [desc,    setDesc]    = useState(lesson.description || '');
  const [tags,    setTags]    = useState({ ...(lesson.tags || {}) });
  const [newFile, setNewFile] = useState(null);
  const [newPrev, setNewPrev] = useState(null);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept:   { 'image/*': ['.jpg','.jpeg','.png','.webp'] },
    multiple: false,
    maxSize:  20 * 1024 * 1024,
    onDropAccepted: ([file]) => {
      if (newPrev) URL.revokeObjectURL(newPrev);
      setNewFile(file);
      setNewPrev(URL.createObjectURL(file));
    },
  });

  const setTag = (key, val, isArray) => {
    setTags((prev) => {
      if (!val) { const n = { ...prev }; delete n[key]; return n; }
      if (isArray) return { ...prev, [key]: [val] };
      if (key === 'hasRhodium') return { ...prev, hasRhodium: val === 'Yes' };
      return { ...prev, [key]: val };
    });
  };

  const handleSave = async () => {
    if (!name.trim()) { setSaveErr('Name is required'); return; }
    setSaveErr(null);
    try {
      await editLesson(lesson.id, {
        file:        newFile || undefined,
        name:        name.trim(),
        description: desc.trim(),
        tags,
      });
      setMode('view');
      setNewFile(null);
      if (newPrev) { URL.revokeObjectURL(newPrev); setNewPrev(null); }
    } catch (err) {
      setSaveErr(err.message);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm(`Delete lesson "${lesson.name}"? This cannot be undone.`)) return;
    setDeleting(true);
    try { await removeLesson(lesson.id); } finally { setDeleting(false); }
  };

  const cancelEdit = () => {
    setMode('view');
    setName(lesson.name);
    setDesc(lesson.description || '');
    setTags({ ...(lesson.tags || {}) });
    if (newPrev) { URL.revokeObjectURL(newPrev); setNewPrev(null); }
    setNewFile(null);
    setSaveErr(null);
  };

  // Visible tags for display
  const displayTags = Object.entries(lesson.tags || {})
    .filter(([, v]) => v !== null && v !== undefined && v !== false)
    .filter(([k]) => TAG_FIELDS.some((f) => f.key === k));

  return (
    <div className={`card overflow-hidden transition-all duration-200
      ${mode === 'edit' ? 'ring-2 ring-amber-400' : 'hover:shadow-md'}
    `}>

      {mode === 'view' ? (
        /* ── View mode ── */
        <div className="flex gap-0">
          {/* Thumbnail */}
          <div className="w-28 shrink-0 bg-gray-100 relative">
            {!imgError && lesson.imageUrl ? (
              <img
                src={lesson.imageUrl}
                alt={lesson.name}
                className="w-full h-full object-cover aspect-square"
                onError={() => setImgError(true)}
              />
            ) : (
              <div className="w-full aspect-square flex items-center justify-center text-3xl">🎓</div>
            )}
            {/* Lesson number badge */}
            <div className="absolute top-1.5 left-1.5 w-5 h-5 rounded-full bg-amber-500
              flex items-center justify-center text-white text-xs font-bold shadow">
              ✓
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 p-3 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-semibold text-gray-800 text-sm leading-tight truncate">{lesson.name}</p>
                {lesson.description && (
                  <p className="text-xs text-gray-500 mt-0.5 line-clamp-2 leading-snug">{lesson.description}</p>
                )}
              </div>
              <div className="flex gap-1 shrink-0">
                <button
                  onClick={() => setMode('edit')}
                  className="text-xs text-amber-600 hover:text-amber-700 hover:bg-amber-50
                             rounded-lg px-2 py-1 transition-colors border border-transparent
                             hover:border-amber-200"
                >
                  Edit
                </button>
                <button
                  onClick={handleDelete}
                  disabled={deleting}
                  className="text-xs text-red-400 hover:text-red-600 hover:bg-red-50
                             rounded-lg px-2 py-1 transition-colors disabled:opacity-50"
                >
                  {deleting ? <Spinner /> : '🗑'}
                </button>
              </div>
            </div>

            {/* Tag chips */}
            {displayTags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {displayTags.slice(0, 6).map(([key, val]) => {
                  const display = Array.isArray(val) ? val.join(', ')
                    : val === true ? 'Rhodium ✓'
                    : val === false ? null
                    : String(val);
                  return display ? (
                    <TagChip key={key} label={display} color={getTagColor(key)} />
                  ) : null;
                })}
              </div>
            )}

            <p className="text-xs text-gray-400 mt-2">
              Added {new Date(lesson.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>
      ) : (
        /* ── Edit mode ── */
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <p className="font-semibold text-gray-800 text-sm">Edit Lesson</p>
            <button onClick={cancelEdit} className="text-xs text-gray-400 hover:text-gray-600">✕ Cancel</button>
          </div>

          {/* Optional image replacement */}
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all text-xs ${
              isDragActive ? 'border-amber-400 bg-amber-50' : 'border-gray-200 hover:border-amber-300'
            }`}
          >
            <input {...getInputProps()} />
            {newPrev ? (
              <div className="flex items-center gap-3">
                <img src={newPrev} alt="new" className="w-12 h-12 rounded object-cover" />
                <span className="text-gray-500">New image selected — drop another to replace</span>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2 text-gray-400">
                <span>🖼️</span>
                <span>Drop a new training image (optional)</span>
              </div>
            )}
          </div>

          {/* Name */}
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-1">Name *</label>
            <input className="input text-sm" value={name} onChange={(e) => setName(e.target.value)} />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-1">
              What to look for <span className="text-gray-400 font-normal">(helps the AI understand)</span>
            </label>
            <textarea
              className="w-full border border-gray-200 rounded-lg p-2.5 text-sm outline-none
                         focus:border-amber-400 focus:ring-1 focus:ring-amber-100 resize-none"
              rows={2}
              placeholder="e.g. small stones flush-set in a flat metal plate around the center stone"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            />
          </div>

          {/* Tag fields */}
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-2">Correct Tags</label>
            <div className="grid grid-cols-2 gap-2">
              {TAG_FIELDS.map(({ key, label, opts, isArray }) => (
                <select
                  key={key}
                  className="select text-xs py-1.5"
                  value={
                    isArray ? (Array.isArray(tags[key]) ? tags[key][0] : '')
                    : key === 'hasRhodium' ? (tags[key] === true ? 'Yes' : tags[key] === false ? 'No' : '')
                    : (tags[key] || '')
                  }
                  onChange={(e) => setTag(key, e.target.value, isArray)}
                >
                  <option value="">{label}</option>
                  {opts.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ))}
            </div>
          </div>

          {saveErr && <p className="text-xs text-red-500 bg-red-50 rounded p-2">{saveErr}</p>}

          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={isSaving || !name.trim()}
              className="btn-gold flex-1 text-sm flex items-center justify-center gap-2"
            >
              {isSaving && <Spinner />}
              {isSaving ? 'Saving…' : 'Save Changes'}
            </button>
            <button onClick={cancelEdit} className="btn-ghost text-sm px-4">Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * ResultCard
 *
 * Reads `result` from allResults via the parent (SearchPage passes it down).
 * All mutations go through the store so allResults stays in sync —
 * no local result state that could go stale.
 *
 * Edit panel:
 *   - Single-item edit: textarea → "Re-Tag" → store.editTag(id, prompt)
 *
 * Selection:
 *   - When selectMode is on, a checkbox overlay appears on the image
 *   - Clicking anywhere on the image card toggles selection
 */
import { useState } from 'react';
import useJewelryStore from '../store/useJewelryStore.js';

const scoreColor = (s) =>
  s >= 0.80 ? 'bg-green-100 text-green-700'
  : s >= 0.60 ? 'bg-amber-100 text-amber-700'
  : 'bg-red-100 text-red-500';

const Chip = ({ label }) =>
  label ? <span className="badge bg-gray-100 text-gray-600">{label}</span> : null;

const Spinner = ({ size = 4 }) => (
  <svg className={`animate-spin w-${size} h-${size} shrink-0`} viewBox="0 0 24 24" fill="none">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
  </svg>
);

export default function ResultCard({ result }) {
  const {
    findSimilar, deleteItem, editTag,
    selectMode, selectedIds, toggleSelectId,
    editingIds,
  } = useJewelryStore((s) => ({
    findSimilar:    s.findSimilar,
    deleteItem:     s.deleteItem,
    editTag:        s.editTag,
    selectMode:     s.selectMode,
    selectedIds:    s.selectedIds,
    toggleSelectId: s.toggleSelectId,
    editingIds:     s.editingIds,
  }));

  const [imgError,     setImgError]     = useState(false);
  const [deleting,     setDeleting]     = useState(false);
  const [showDetails,  setShowDetails]  = useState(false);
  const [showEdit,     setShowEdit]     = useState(false);
  const [prompt,       setPrompt]       = useState('');
  const [editError,    setEditError]    = useState(null);

  const isSelected  = selectedIds.has(result.id);
  const isEditing   = editingIds.has(result.id);  // driven by store — accurate

  const handleDelete = async () => {
    if (!window.confirm(`Remove "${result.id}" from catalog?`)) return;
    setDeleting(true);
    try { await deleteItem(result.id); } finally { setDeleting(false); }
  };

  const handleRetag = async () => {
    if (!prompt.trim()) return;
    setEditError(null);
    try {
      await editTag(result.id, prompt.trim());
      // On success: store has already patched allResults, card re-renders
      setShowEdit(false);
      setPrompt('');
    } catch (err) {
      setEditError(err.response?.data?.error || err.message);
    }
  };

  const handleImageClick = () => {
    if (selectMode) toggleSelectId(result.id);
  };

  return (
    <div className={`card overflow-hidden transition-all duration-200 hover:shadow-md group
      ${isSelected ? 'ring-2 ring-amber-500' : ''}
      ${isEditing  ? 'opacity-75' : ''}
    `}>

      {/* ── Image ── */}
      <div
        className={`relative aspect-square bg-gray-100 overflow-hidden
          ${selectMode ? 'cursor-pointer' : ''}
        `}
        onClick={handleImageClick}
      >
        {!imgError && result.imageUrl ? (
          <img
            src={result.imageUrl}
            alt={result.title || result.fileName}
            className={`w-full h-full object-cover transition-transform duration-300
              ${!selectMode ? 'group-hover:scale-105' : ''}
            `}
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl">💎</div>
        )}

        {/* Score badge */}
        {!selectMode && (
          <div className={`absolute top-2 right-2 badge font-semibold ${scoreColor(result.score)}`}>
            {Math.round(result.score * 100)}%
          </div>
        )}

        {/* Selection checkbox */}
        {selectMode && (
          <div className={`absolute inset-0 flex items-center justify-center
            ${isSelected ? 'bg-amber-500/20' : 'bg-black/10 hover:bg-black/20'}
            transition-colors duration-150`}
          >
            <div className={`w-7 h-7 rounded-full border-2 flex items-center justify-center
              shadow-lg transition-all duration-150
              ${isSelected
                ? 'bg-amber-500 border-amber-500'
                : 'bg-white/90 border-gray-300'}
            `}>
              {isSelected && <span className="text-white text-sm font-bold">✓</span>}
            </div>
          </div>
        )}

        {/* Editing overlay */}
        {isEditing && (
          <div className="absolute inset-0 bg-white/70 flex flex-col items-center justify-center gap-2">
            <Spinner size={6} />
            <p className="text-xs text-gray-600 font-medium">Re-tagging…</p>
          </div>
        )}

        {/* Edit pencil button (hidden in select mode) */}
        {!selectMode && !isEditing && (
          <button
            onClick={(e) => { e.stopPropagation(); setShowEdit((x) => !x); setEditError(null); }}
            title="Edit tags"
            className={`absolute top-2 left-2 w-7 h-7 rounded-full flex items-center justify-center
              text-sm shadow transition-all
              ${showEdit
                ? 'bg-amber-500 text-white'
                : 'bg-white/90 hover:bg-amber-50 text-gray-600'}
            `}
          >
            ✏️
          </button>
        )}
      </div>

      {/* ── Body ── */}
      {showEdit && !isEditing ? (
        /* ── Edit panel ── */
        <div className="p-3 space-y-2">
          <p className="text-xs font-semibold text-gray-700">Correct tags for this item</p>
          <p className="text-xs text-gray-400 leading-snug">
            Describe what's wrong, e.g. "metal is rose gold not yellow gold" or "add PEAR to stone shapes"
          </p>
          <textarea
            className="w-full min-h-[90px] max-h-[140px] border border-gray-200 rounded-lg p-2
                       outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-100
                       text-sm resize-none transition-all"
            placeholder="e.g. stone shape should be OVAL not ROUND…"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleRetag();
            }}
            autoFocus
          />
          {editError && (
            <p className="text-xs text-red-500 bg-red-50 rounded p-1.5">{editError}</p>
          )}
          <div className="flex gap-2">
            <button
              onClick={handleRetag}
              disabled={!prompt.trim()}
              className="btn-gold flex-1 text-xs py-1.5 flex items-center justify-center gap-1.5"
            >
              Re-Tag
            </button>
            <button
              onClick={() => { setShowEdit(false); setPrompt(''); setEditError(null); }}
              className="btn-ghost text-xs py-1.5 px-3"
            >
              Cancel
            </button>
          </div>
          <p className="text-xs text-gray-400 text-center">⌘ Enter to submit</p>
        </div>
      ) : (
        /* ── Normal view ── */
        <div className="p-3 space-y-2">
          <p className="text-sm font-semibold text-gray-800 leading-tight line-clamp-2">
            {result.title || result.fileName || result.id}
          </p>
          <p className="text-xs text-gray-400">SKU: {result.sku}</p>

          <div className="flex flex-wrap gap-1">
            <Chip label={result.category} />
            <Chip label={result.metalColor} />
            <Chip label={result.gemstone} />
            <Chip label={result.settingStyle} />
          </div>

          {/* Stone shapes */}
          {result.stoneShapes?.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {result.stoneShapes.slice(0, 3).map((s) => (
                <span key={s} className="badge bg-blue-50 text-blue-600 border border-blue-100 text-xs">{s}</span>
              ))}
            </div>
          )}

          {result.description && (
            <div>
              <p className={`text-xs text-gray-500 leading-relaxed ${showDetails ? '' : 'line-clamp-2'}`}>
                {result.description}
              </p>
              {result.description.length > 80 && (
                <button
                  onClick={() => setShowDetails((x) => !x)}
                  className="text-xs text-amber-600 hover:text-amber-700"
                >
                  {showDetails ? 'Less' : 'More'}
                </button>
              )}
            </div>
          )}

          {!selectMode && (
            <div className="flex gap-2 pt-1">
              <button
                onClick={() => findSimilar(result.id)}
                className="flex-1 text-xs bg-gray-50 hover:bg-amber-50 text-gray-600
                           hover:text-amber-700 border border-gray-200 hover:border-amber-200
                           rounded-lg py-1.5 transition-colors"
              >
                Find Similar
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="text-xs text-red-400 hover:text-red-600 hover:bg-red-50
                           border border-transparent hover:border-red-100 rounded-lg
                           px-2 py-1.5 transition-colors disabled:opacity-50"
              >
                {deleting ? <Spinner size={3} /> : '🗑'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

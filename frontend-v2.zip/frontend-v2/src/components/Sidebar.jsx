import { NavLink } from 'react-router-dom';
import { useEffect } from 'react';
import useJewelryStore from '../store/useJewelryStore.js';
import useTrainingStore from '../store/useTrainingStore.js';

const navItems = [
  { to: '/',         label: 'Search',      icon: '🔍' },
  { to: '/upload',   label: 'Add Jewelry', icon: '📤' },
  { to: '/training', label: 'AI Training', icon: '🎓' },
];

export default function Sidebar() {
  const { stats, fetchStats }           = useJewelryStore((s) => ({ stats: s.stats, fetchStats: s.fetchStats }));
  const { lessonCount, loadLessonCount } = useTrainingStore((s) => ({ lessonCount: s.lessonCount, loadLessonCount: s.loadLessonCount }));

  useEffect(() => {
    fetchStats();
    loadLessonCount();
  }, []);

  return (
    <aside className="w-56 shrink-0 bg-zinc-900 min-h-screen flex flex-col">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <span className="text-2xl">💎</span>
          <div>
            <p className="text-white font-semibold text-sm leading-tight">Jewelry AI</p>
            <p className="text-zinc-400 text-xs">Vector Search</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map(({ to, label, icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ` +
              (isActive
                ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800')
            }
          >
            <span>{icon}</span>
            <span className="flex-1">{label}</span>
            {/* Lesson count badge on Training */}
            {to === '/training' && lessonCount > 0 && (
              <span className="bg-amber-500/20 text-amber-400 text-xs font-semibold px-1.5 py-0.5 rounded-full">
                {lessonCount}
              </span>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Stats */}
      <div className="px-4 py-4 border-t border-zinc-800 space-y-3">
        <div>
          <p className="text-zinc-500 text-xs uppercase tracking-wider mb-2">Catalog</p>
          <div className="bg-zinc-800 rounded-lg p-3">
            <p className="text-white text-xl font-bold">{stats?.totalVectors ?? '—'}</p>
            <p className="text-zinc-400 text-xs mt-0.5">items indexed</p>
          </div>
          <p className="text-zinc-600 text-xs mt-1.5 truncate">{stats?.indexName ?? 'jewelry-search'}</p>
        </div>

        {lessonCount > 0 && (
          <div>
            <p className="text-zinc-500 text-xs uppercase tracking-wider mb-2">Training</p>
            <div className="bg-zinc-800 rounded-lg p-3">
              <p className="text-amber-400 text-xl font-bold">{lessonCount}</p>
              <p className="text-zinc-400 text-xs mt-0.5">lesson{lessonCount !== 1 ? 's' : ''} active</p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

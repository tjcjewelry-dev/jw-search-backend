import { useDropzone } from 'react-dropzone';
import useJewelryStore from '../store/useJewelryStore.js';

const ACCEPTED = { 'image/jpeg': ['.jpg', '.jpeg'], 'image/png': ['.png'], 'image/webp': ['.webp'] };

export default function UploadZone() {
  const addToQueue = useJewelryStore((s) => s.addToQueue);

  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    accept: ACCEPTED,
    multiple: true,
    maxSize: 20 * 1024 * 1024,
    onDropAccepted: (files) => addToQueue(files),
    onDropRejected: (rejected) => {
      rejected.forEach((r) => console.warn('Rejected:', r.file.name, r.errors));
    },
  });

  return (
    <div
      {...getRootProps()}
      className={`
        relative border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer
        transition-all duration-200 select-none
        ${isDragReject ? 'border-red-400 bg-red-50'
          : isDragActive ? 'border-amber-400 bg-amber-50 scale-[1.01]'
          : 'border-gray-200 bg-gray-50 hover:border-amber-300 hover:bg-amber-50/50'}
      `}
    >
      <input {...getInputProps()} />

      <div className="flex flex-col items-center gap-3 pointer-events-none">
        <div className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl
          ${isDragActive ? 'bg-amber-100' : 'bg-white shadow-sm border border-gray-100'}`}>
          {isDragReject ? '🚫' : isDragActive ? '✨' : '🖼️'}
        </div>

        {isDragReject ? (
          <p className="text-red-500 font-medium">Only JPG, PNG, WEBP files allowed</p>
        ) : isDragActive ? (
          <p className="text-amber-600 font-semibold">Drop to add to queue</p>
        ) : (
          <>
            <div>
              <p className="text-gray-700 font-semibold">Drop jewelry images here</p>
              <p className="text-gray-400 text-sm mt-1">or click to browse — JPG, PNG, WEBP up to 20MB</p>
            </div>
            <p className="text-xs text-gray-400 bg-white border border-gray-100 rounded-full px-3 py-1">
              Multiple images supported · GPT-4o Mini will auto-tag each one
            </p>
          </>
        )}
      </div>
    </div>
  );
}
